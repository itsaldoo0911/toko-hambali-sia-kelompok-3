/* SIA Toko Hambali - interaksi prototype. Data tersimpan lokal pada browser perangkat. */
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const rupiah = (n) => new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(Number(n)||0);
  const today = () => new Date().toISOString().slice(0,10);
  const clone = (v) => JSON.parse(JSON.stringify(v));
  const sampleProducts = [
    {kode:'BRG001',nama:'Beras Premium 5 Kg',satuan:'Karung',jual:75000,beli:68000,stok:25,min:5},
    {kode:'BRG002',nama:'Minyak Goreng 1 L',satuan:'Pcs',jual:18000,beli:15500,stok:40,min:8},
    {kode:'BRG003',nama:'Gula Pasir 1 Kg',satuan:'Kg',jual:17000,beli:14500,stok:35,min:8},
    {kode:'BRG004',nama:'Telur Ayam 1 Kg',satuan:'Kg',jual:30000,beli:27000,stok:20,min:5},
    {kode:'BRG005',nama:'Mi Instan',satuan:'Pcs',jual:3500,beli:2800,stok:100,min:20},
    {kode:'BRG006',nama:'Air Mineral 600 ml',satuan:'Botol',jual:4000,beli:2500,stok:60,min:12}
  ];
  const emptyState = () => ({products:clone(sampleProducts),sales:[],purchases:[],stock:[],damages:[],cash:[],wa:[]});
  let state;
  try { state = JSON.parse(localStorage.getItem('siaHambaliDataV1')) || emptyState(); }
  catch(e) { state = emptyState(); }
  for (const k of ['products','sales','purchases','stock','damages','cash','wa']) if (!Array.isArray(state[k])) state[k]=[];
  const save = () => { try { localStorage.setItem('siaHambaliDataV1',JSON.stringify(state)); } catch(e) { alert('Penyimpanan browser penuh atau tidak tersedia.'); } };
  const product = (kode) => state.products.find(p=>p.kode===kode);
  const safe = (s) => String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const empty = (cols,msg='Belum ada data') => `<tr><td class="empty-row" colspan="${cols}">${msg}</td></tr>`;
  const rowAction = (type,id) => `<button type="button" class="action-btn" data-delete="${type}" data-id="${safe(id)}">Hapus</button>`;

  // Tambahkan Pesanan WA, karena belum terdapat pada HTML yang dikirim.
  function addWhatsAppSection(){
    const nav=$('.nav');
    if(nav && !nav.querySelector('[data-section="wa"]')){
      const b=document.createElement('button'); b.type='button'; b.className='nav-item'; b.dataset.section='wa'; b.innerHTML='<span class="nav-icon">💬</span> Pesanan WA';
      const pos=nav.querySelector('[data-section="penjualan"]'); if(pos) pos.after(b); else nav.append(b);
    }
    const content=document.querySelector('.content');
    if(content && !$('wa')){
      const sec=document.createElement('section'); sec.id='wa'; sec.className='section';
      sec.innerHTML=`<div class="card"><div class="card-header"><h3>Pesanan WhatsApp</h3><p class="hint">Catat pesanan pelanggan yang masuk melalui WhatsApp.</p></div>
      <form id="formWA" class="form-grid">
      <div class="form-group"><label>Nama Pelanggan</label><input id="waNama" required placeholder="Nama pelanggan"></div>
      <div class="form-group"><label>Nomor WhatsApp</label><input id="waNomor" required type="tel" placeholder="08xxxxxxxxxx"></div>
      <div class="form-group"><label>Tanggal Pesanan</label><input id="waTanggal" type="date" required></div>
      <div class="form-group"><label>Barang</label><select id="waKode" required><option value="">Pilih barang...</option></select></div>
      <div class="form-group"><label>Qty</label><input id="waQty" type="number" min="1" value="1" required></div>
      <div class="form-group"><label>Status</label><select id="waStatus"><option>Menunggu</option><option>Diproses</option><option>Siap Diambil</option><option>Selesai</option><option>Dibatalkan</option></select></div>
      <div class="form-group full"><label>Catatan</label><input id="waCatatan" placeholder="Catatan pesanan (opsional)"></div>
      <div class="form-group full"><button class="btn primary" type="submit">+ Catat Pesanan WA</button></div></form>
      <div class="table-wrap"><table><thead><tr><th>Tanggal</th><th>Pelanggan</th><th>WhatsApp</th><th>Barang</th><th>Qty</th><th>Total</th><th>Status</th><th>Catatan</th><th>Aksi</th></tr></thead><tbody id="waBody"></tbody></table></div></div>`;
      content.append(sec);
    }
  }
  addWhatsAppSection();

  const titles={dashboard:['Dashboard','Ringkasan keuangan & operasional November 2026'],produk:['Master Barang','Data barang dan persediaan'],penjualan:['Penjualan POS','Pencatatan transaksi penjualan'],pembelian:['Pembelian','Pencatatan pembelian barang'],stok:['Stok Opname','Pemeriksaan stok fisik dan sistem'],rusak:['Rusak & ED','Pencatatan barang rusak, hilang, atau kedaluwarsa'],kas:['Kas & Prive','Penerimaan dan pengeluaran kas'],pajak:['Rekap Pajak','Simulasi rekap pajak final'],laporan:['Laporan Produk','Kontribusi penjualan setiap produk'],petunjuk:['Petunjuk','Panduan penggunaan aplikasi'],wa:['Pesanan WA','Pencatatan pesanan pelanggan melalui WhatsApp']};
  function showSection(id){
    if(!$ (id)) return;
    document.querySelectorAll('.section').forEach(s=>s.classList.toggle('active',s.id===id));
    document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.section===id));
    const t=titles[id]||[id,'']; if($('pageTitle')) $('pageTitle').textContent=t[0]; if($('pageSubtitle')) $('pageSubtitle').textContent=t[1];
    $('sidebar')?.classList.remove('open');
    window.scrollTo({top:0,behavior:'smooth'});
  }
  document.addEventListener('click',e=>{
    const nav=e.target.closest('.nav-item[data-section]');
    if(nav){e.preventDefault();showSection(nav.dataset.section);return;}
    const del=e.target.closest('[data-delete]');
    if(del){deleteRow(del.dataset.delete,del.dataset.id);}
  });
  $('menuToggle')?.addEventListener('click',()=>$('sidebar')?.classList.toggle('open'));
  document.addEventListener('click',e=>{if(window.innerWidth<=760 && $('sidebar')?.classList.contains('open') && !e.target.closest('#sidebar') && !e.target.closest('#menuToggle')) $('sidebar').classList.remove('open');});

  function fillProductSelect(id){const el=$(id);if(!el)return;const old=el.value;el.innerHTML='<option value="">Pilih barang...</option>'+state.products.map(p=>`<option value="${safe(p.kode)}">${safe(p.kode)} — ${safe(p.nama)}</option>`).join('');if(state.products.some(p=>p.kode===old))el.value=old;}
  function renderProducts(){
    const body=$('masterBarangBody');if(body)body.innerHTML=state.products.length?state.products.map(p=>`<tr><td>${safe(p.kode)}</td><td>${safe(p.nama)}</td><td>${safe(p.satuan)}</td><td>${rupiah(p.jual)}</td><td>${rupiah(p.beli)}</td><td>${p.stok}</td><td>${p.min}</td><td><span class="small-status ${p.stok<=p.min?'bad':''}">${p.stok<=p.min?'Stok Menipis':'Aktif'}</span> ${rowAction('produk',p.kode)}</td></tr>`).join(''):empty(8);
    ['posKode','stokKode','rusakKode','waKode'].forEach(fillProductSelect);
  }
  function renderSales(){const b=$('penjualanBody');if(b)b.innerHTML=state.sales.length?state.sales.map(x=>`<tr><td>${safe(x.nota)}</td><td>${safe(x.tanggal)}</td><td>${safe(x.kode)}</td><td>${safe(x.nama)}</td><td>${x.qty}</td><td>${rupiah(x.harga)}</td><td>${rupiah(x.diskon)}</td><td>${rupiah(x.total)}</td><td>${safe(x.metode)}</td><td>${rowAction('sales',x.id)}</td></tr>`).join(''):empty(10);}
  function renderPurchases(){const b=$('pembelianBody');if(b)b.innerHTML=state.purchases.length?state.purchases.map(x=>`<tr><td>${safe(x.nota)}</td><td>${safe(x.tanggal)}</td><td>${safe(x.pemasok)}</td><td>${safe(x.jenis)}</td><td>${rupiah(x.nilai)}</td><td>${safe(x.metode)}</td><td>${safe(x.bukti)}</td><td><span class="small-status ${x.bukti==='Ya'?'':'bad'}">${x.bukti==='Ya'?'Diterima':'Ditolak'}</span></td><td>${rowAction('purchases',x.id)}</td></tr>`).join(''):empty(9);}
  function renderStock(){const b=$('stokBody');if(b)b.innerHTML=state.stock.length?state.stock.map(x=>`<tr><td>${safe(x.tanggal)}</td><td>${safe(x.kode)}</td><td>${safe(x.nama)}</td><td>${x.sistem}</td><td>${x.fisik}</td><td>${x.selisih>0?'+':''}${x.selisih}</td><td>${safe(x.alasan||'-')}</td><td>${x.selisih===0?'Sesuai':'Perlu pemeriksaan'}</td><td>${rowAction('stock',x.id)}</td></tr>`).join(''):empty(9);}
  function renderDamages(){const b=$('rusakBody');if(b)b.innerHTML=state.damages.length?state.damages.map(x=>`<tr><td>${safe(x.tanggal)}</td><td>${safe(x.kode)}</td><td>${safe(x.nama)}</td><td>${x.qty}</td><td>${safe(x.alasan)}</td><td>${safe(x.ed||'-')}</td><td>${rupiah(x.nilai)}</td><td>${rowAction('damages',x.id)}</td></tr>`).join(''):empty(8);}
  function renderCash(){const b=$('kasBody');if(b)b.innerHTML=state.cash.length?state.cash.map(x=>`<tr><td>${safe(x.tanggal)}</td><td>${safe(x.jenis)}</td><td>${safe(x.ket)}</td><td>${rupiah(x.jumlah)}</td><td>${safe(x.akun)}</td><td>${rowAction('cash',x.id)}</td></tr>`).join(''):empty(6);}
  function renderWA(){const b=$('waBody');if(b)b.innerHTML=state.wa.length?state.wa.map(x=>`<tr><td>${safe(x.tanggal)}</td><td>${safe(x.nama)}</td><td>${safe(x.nomor)}</td><td>${safe(x.produk)}</td><td>${x.qty}</td><td>${rupiah(x.total)}</td><td>${safe(x.status)}</td><td>${safe(x.catatan||'-')}</td><td>${rowAction('wa',x.id)}</td></tr>`).join(''):empty(9);}
  function renderTax(){const b=$('pajakBody');if(b){const kum=136000000,above=Math.max(0,kum-500000000);b.innerHTML=`<tr><td>November 2026</td><td>${rupiah(12800000)}</td><td>${rupiah(kum)}</td><td>${rupiah(above)}</td><td>${rupiah(above*.005)}</td></tr>`;}}
  function renderReports(){const b=$('laporanBody');if(!b)return;const sums={};state.sales.forEach(s=>{sums[s.kode]=(sums[s.kode]||0)+s.total;});const total=Object.values(sums).reduce((a,v)=>a+v,0);b.innerHTML=state.products.map(p=>{const qty=state.sales.filter(s=>s.kode===p.kode).reduce((a,s)=>a+s.qty,0);const val=sums[p.kode]||0;return `<tr><td>${safe(p.nama)}</td><td>${qty}</td><td>${rupiah(val)}</td><td>${total?((val/total)*100).toFixed(1)+'%':'0%'}</td></tr>`;}).join('')||empty(4);}
  function renderStats(){
    const baseSales=12800000,baseHpp=10560000,added=state.sales.reduce((a,s)=>a+s.total,0),addedHpp=state.sales.reduce((a,s)=>a+(product(s.kode)?.beli||0)*s.qty,0);
    if($('statPenjualan'))$('statPenjualan').textContent=rupiah(baseSales+added);
    if($('statHPP'))$('statHPP').textContent=rupiah(baseHpp+addedHpp);
    if($('statLabaKotor'))$('statLabaKotor').textContent=rupiah((baseSales+added)-(baseHpp+addedHpp));
    if($('statLabaBersih'))$('statLabaBersih').textContent=rupiah(1490000+added-addedHpp);
  }
  function renderAll(){renderProducts();renderSales();renderPurchases();renderStock();renderDamages();renderCash();renderWA();renderTax();renderReports();renderStats();}
  function id(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7);}
  function value(id){return $(id)?.value?.trim()??'';}
  function number(id){return Number($(id)?.value||0);}
  function resetDateInputs(){['posTanggal','beliTanggal','stokTanggal','rusakTanggal','kasTanggal','waTanggal'].forEach(x=>{if($(x))$(x).value=today();});}

  $('formPOS')?.addEventListener('submit',e=>{e.preventDefault();const p=product(value('posKode')),qty=number('posQty'),diskon=number('posDiskon');if(!p)return alert('Pilih barang terlebih dahulu.');if(qty<1||qty>p.stok)return alert(`Stok tidak mencukupi. Stok tersedia: ${p.stok}`);const harga=p.jual,total=Math.max(0,harga*qty-diskon);state.sales.push({id:id(),nota:value('posNota'),tanggal:value('posTanggal'),kode:p.kode,nama:p.nama,qty,harga,diskon,total,metode:value('posMetode')});p.stok-=qty;save();renderAll();e.target.reset();$('posQty').value=1;$('posDiskon').value=0;resetDateInputs();alert('Transaksi penjualan berhasil dicatat.');});
  $('formPembelian')?.addEventListener('submit',e=>{e.preventDefault();const item={id:id(),nota:value('beliNota'),tanggal:value('beliTanggal'),pemasok:value('beliPemasok'),jenis:value('beliJenis'),nilai:number('beliNilai'),metode:value('beliMetode'),bukti:value('beliBukti')};if(item.nilai<=0)return alert('Nilai pembelian harus lebih dari 0.');state.purchases.push(item);if(item.bukti==='Ya'&&item.jenis==='Persediaan'){}save();renderAll();e.target.reset();resetDateInputs();alert(item.bukti==='Ya'?'Pembelian berhasil dicatat.':'Pembelian dicatat dengan status DITOLAK karena bukti nota tidak ada.');});
  $('formStok')?.addEventListener('submit',e=>{e.preventDefault();const p=product(value('stokKode'));if(!p)return alert('Pilih barang.');const sistem=number('stokSistem'),fisik=number('stokFisik'),selisih=fisik-sistem,alasan=value('stokAlasan');if(selisih!==0&&!alasan)return alert('Isi alasan jika terdapat selisih stok.');state.stock.push({id:id(),tanggal:value('stokTanggal'),kode:p.kode,nama:p.nama,sistem,fisik,selisih,alasan});p.stok=fisik;save();renderAll();e.target.reset();resetDateInputs();alert('Stok opname berhasil dicatat.');});
  $('formRusak')?.addEventListener('submit',e=>{e.preventDefault();const p=product(value('rusakKode')),qty=number('rusakQty');if(!p)return alert('Pilih barang.');if(qty<1||qty>p.stok)return alert(`Qty melebihi stok. Stok tersedia: ${p.stok}`);state.damages.push({id:id(),tanggal:value('rusakTanggal'),kode:p.kode,nama:p.nama,qty,alasan:value('rusakAlasan'),ed:value('rusakED'),nilai:p.beli*qty});p.stok-=qty;save();renderAll();e.target.reset();$('rusakQty').value=1;resetDateInputs();alert('Kerugian barang berhasil dicatat.');});
  $('formKas')?.addEventListener('submit',e=>{e.preventDefault();const jenis=value('kasJenis');state.cash.push({id:id(),tanggal:value('kasTanggal'),jenis,ket:value('kasKet'),jumlah:number('kasJumlah'),akun:jenis==='Prive'?'Prive':jenis==='Penerimaan Lain'?'Pendapatan lain':'Beban operasional'});save();renderAll();e.target.reset();resetDateInputs();alert('Transaksi kas berhasil dicatat.');});
  $('formWA')?.addEventListener('submit',e=>{e.preventDefault();const p=product(value('waKode')),qty=number('waQty');if(!p)return alert('Pilih barang.');if(qty<1)return alert('Qty minimal 1.');state.wa.push({id:id(),tanggal:value('waTanggal'),nama:value('waNama'),nomor:value('waNomor'),kode:p.kode,produk:p.nama,qty,total:p.jual*qty,status:value('waStatus'),catatan:value('waCatatan')});save();renderAll();e.target.reset();$('waQty').value=1;resetDateInputs();alert('Pesanan WhatsApp berhasil dicatat.');});

  function deleteRow(type,rowId){const labels={produk:'barang',sales:'transaksi penjualan',purchases:'pembelian',stock:'stok opname',damages:'catatan kerugian',cash:'transaksi kas',wa:'pesanan WhatsApp'};if(!confirm(`Hapus ${labels[type]||'data'} ini?`))return;
    if(type==='produk'){if(state.sales.some(x=>x.kode===rowId)||state.wa.some(x=>x.kode===rowId))return alert('Barang sudah digunakan dalam transaksi/pesanan, tidak dapat dihapus.');state.products=state.products.filter(x=>x.kode!==rowId);}else{state[type]=state[type].filter(x=>x.id!==rowId);}save();renderAll();}

  // Tambahkan form master barang yang tidak tersedia di HTML awal.
  const masterCard=$('masterBarangBody')?.closest('.card');
  if(masterCard&&!$('formProduk')){const form=document.createElement('form');form.id='formProduk';form.className='form-grid';form.style.marginTop='16px';form.innerHTML=`<div class="form-group"><label>Kode Barang Baru</label><input id="produkKode" required placeholder="BRG007"></div><div class="form-group"><label>Nama Barang</label><input id="produkNama" required placeholder="Nama barang"></div><div class="form-group"><label>Satuan</label><input id="produkSatuan" required placeholder="Pcs / Kg / Botol"></div><div class="form-group"><label>Harga Jual (Rp)</label><input id="produkJual" type="number" min="1" required></div><div class="form-group"><label>Harga Beli (Rp)</label><input id="produkBeli" type="number" min="0" required></div><div class="form-group"><label>Stok Awal</label><input id="produkStok" type="number" min="0" value="0" required></div><div class="form-group"><label>Minimum Stok</label><input id="produkMin" type="number" min="0" value="0" required></div><div class="form-group full"><button type="submit" class="btn primary">+ Tambah Barang</button></div>`;masterCard.append(form);form.addEventListener('submit',e=>{e.preventDefault();const kode=value('produkKode').toUpperCase();if(state.products.some(p=>p.kode===kode))return alert('Kode barang sudah digunakan.');state.products.push({kode,nama:value('produkNama'),satuan:value('produkSatuan'),jual:number('produkJual'),beli:number('produkBeli'),stok:number('produkStok'),min:number('produkMin')});save();renderAll();e.target.reset();alert('Barang baru berhasil ditambahkan.');});}

  resetDateInputs();renderAll();
})();
